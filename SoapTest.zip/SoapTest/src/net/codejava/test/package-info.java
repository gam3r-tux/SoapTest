@javax.xml.bind.annotation.XmlSchema(namespace = "http://codejava.net/")
package net.codejava.test;
